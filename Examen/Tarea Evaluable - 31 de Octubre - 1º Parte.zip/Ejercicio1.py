# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 10:16:47 2023

@author: agonjur
"""

#Ejercicio 1


lista = list(range(0,11))
print(lista, list.reverse(lista))