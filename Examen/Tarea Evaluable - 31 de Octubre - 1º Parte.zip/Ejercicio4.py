# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 10:31:54 2023

@author: agonjur
"""

#Ejercicio 4

lista1 =  [1, 5, 8, 4, 3]
lista2 = [4, 5, 2, 1]

for a in lista1 and lista2:
    if a in lista1 and lista2:
        print("Si existen elementos repetidos en ambas listas.")    