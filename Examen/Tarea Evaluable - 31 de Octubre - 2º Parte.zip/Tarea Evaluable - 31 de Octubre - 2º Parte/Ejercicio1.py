# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 12:33:48 2023

@author: agonjur
"""

x = 0
while x < 5:
    x += 1
    if x == 3:
        break     #Esto es lo que habría que escribir en el signo de interrogación.
    print(x)